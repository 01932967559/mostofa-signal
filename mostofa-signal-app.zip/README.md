# Mostofa Signal App

Upload index.html to your GitHub repository root and enable GitHub Pages.